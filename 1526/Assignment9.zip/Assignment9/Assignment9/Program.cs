﻿namespace Assignment9;

internal static class Program
{
    private static void Main()
    {
        StartApp.Start();
    }
}