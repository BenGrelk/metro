namespace Assignment1;

public interface IPayable
{
    public decimal GetPaymentAmount();
}